import React from 'react';
import PersonaLayout from '../components/PersonaLayout';
import PersonaSection from '../components/PersonaSection';

function TalentPersona() {
  const contentIdeas = [
    {
      title: "Beyond the Algorithm",
      trigger: "Challenge: Maintaining human touch in digital recruitment",
      description: "Leverage technology ethically for talent sourcing while maintaining human focus and ensuring compliance with UK data privacy and anti-discrimination laws."
    },
    {
      title: "The EVP Advantage",
      trigger: "Pain Point: Standing out in competitive market",
      description: "Craft a compelling UK employer value proposition that addresses cost-of-living concerns while highlighting flexible work, well-being benefits, and career development."
    },
    {
      title: "Building Bridges",
      trigger: "Motivation: Creating sustainable talent pipelines",
      description: "Develop strategic partnerships with educational institutions and underrepresented communities to address UK skills shortages and build diverse talent pipelines."
    }
  ];

  return (
    <PersonaLayout title="UK Talent Acquisition Leader Persona" contentIdeas={contentIdeas}>
      <PersonaSection
        title="Goal Statement"
        items={[
          'Build a diverse, skilled workforce aligned with organizational objectives and values, going beyond filling roles to find the right people to thrive in the dynamic UK market while ensuring compliance, driving DEI, and supporting ESG commitments.'
        ]}
      />
      
      <PersonaSection
        title="Key Needs"
        items={[
          'UK-specific labor analytics and real-time market intelligence',
          'Ethical AI and ATS solutions meeting UK data privacy standards',
          'DEI-focused tools for reducing bias and ensuring inclusive practices',
          'Compelling UK value proposition addressing cost-of-living concerns',
          'University and industry partnerships for accessing emerging talent',
          'Strategic alignment with C-suite on growth plans and ROI justification',
          'Guidance on UK employment law compliance and regulations'
        ]}
      />
      
      <PersonaSection
        title="What Makes This Persona Unique to the UK"
        items={[
          'Robust regulatory landscape requiring deep understanding and adherence',
          'Severe skills shortages and intense competition for talent',
          'Hybrid/remote workforce norms necessitating adapted recruitment strategies',
          'ESG and DEI priorities increasingly important for employer branding',
          'Cost-of-living and wage inflation impacting compensation expectations'
        ]}
      />
      
      <PersonaSection
        title="Key Insights for Collaboration"
        items={[
          'Need for deep UK-specific market knowledge',
          'Focus on demonstrable ROI and efficiency gains',
          'Requirement for flexible, integrated solutions',
          'Support for distinctive employer branding',
          'Emphasis on regulatory compliance and ethical practices'
        ]}
      />
    </PersonaLayout>
  );
}

export default TalentPersona;