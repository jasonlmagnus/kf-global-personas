import React from 'react';
import PersonaLayout from '../components/PersonaLayout';
import PersonaSection from '../components/PersonaSection';

function CeoPersona() {
  const contentIdeas = [
    {
      title: "The Illusion of Control",
      trigger: "Challenge: Desire for control in an uncertain environment",
      description: "Shift from seeking absolute control to fostering organizational agility as a means of navigating British economic and regulatory volatility, focusing on scenario planning and flexible strategic pivots."
    },
    {
      title: "Decoding the Signals",
      trigger: "Pain Point: Complex UK market indicators creating uncertainty",
      description: "Interpret complex UK-specific economic indicators (inflation, post-Brexit rules, 'Invest 2035' priorities) to make more informed strategic decisions, emphasizing data-driven insights."
    },
    {
      title: "Building a Legacy of Certainty",
      trigger: "Motivation: Creating long-term stability in volatile markets",
      description: "Position ESG as a fundamental strategy for building a stable and trustworthy brand in the eyes of UK investors, employees, and customers, creating long-term predictability and resilience."
    }
  ];

  return (
    <PersonaLayout title="UK CEO Persona" contentIdeas={contentIdeas}>
      <PersonaSection
        title="Goal Statement"
        items={[
          'Drive sustainable growth amid economic and regulatory complexity, integrate ESG as a core differentiator, and capitalize on emerging digital technologies—ultimately ensuring organizational competitiveness and resilience in British and global markets.'
        ]}
      />
      
      <PersonaSection
        title="Key Needs"
        items={[
          'Strategic Growth: Navigate the Bank of England\'s monetary policy shifts and their impact on business strategy, particularly in high-inflation sectors.',
          'Regulatory & Legal Compliance: Master the evolving British regulatory landscape, from the Digital Markets Act to the Corporate Governance Code reforms.',
          'Digital Transformation & AI Integration: Align with the UK AI White Paper guidelines while leveraging Tech Nation initiatives for digital skills development.',
          'Talent Acquisition & Retention: Address skills shortages in key sectors like green technology and fintech, particularly in regional tech hubs like Manchester and Leeds.',
          'ESG Integration: Navigate Sustainability Disclosure Requirements (SDR) and implement Task Force on Climate-related Financial Disclosures (TCFD) reporting.'
        ]}
      />
      
      <PersonaSection
        title="Key Responsibilities"
        items={[
          'Aligning business strategy with British Industrial Strategy sectors and regional development initiatives.',
          'Leading digital transformation while adhering to UK-specific AI safety and ethics frameworks.',
          'Ensuring compliance with evolving British corporate governance standards and ESG reporting requirements.',
          'Building relationships with regional authorities and Local Enterprise Partnerships (LEPs).',
          'Managing stakeholder expectations around Net Zero transition plans and carbon reduction commitments.'
        ]}
      />
      
      <PersonaSection
        title="What Makes This Persona Unique to the UK"
        items={[
          'Navigating post-Brexit opportunities in free ports and investment zones.',
          'Managing energy costs amid British market volatility and green transition.',
          'Balancing London-centric operations with regional growth opportunities.',
          'Adapting to British corporate governance reforms and director responsibilities.',
          'Understanding devolved administration impacts on business operations.'
        ]}
      />
    </PersonaLayout>
  );
}

export default CeoPersona;