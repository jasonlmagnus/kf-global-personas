import React from 'react';
import { Link } from 'react-router-dom';
import { Users, User2, UserCog, Brain, Briefcase, UserPlus } from 'lucide-react';

function Index() {
  const personas = [
    {
      title: 'UK CEO',
      icon: User2,
      path: '/ceo',
      description: 'Strategic leader focused on sustainable growth and innovation in the UK market'
    },
    {
      title: 'UK CHRO',
      icon: Users,
      path: '/chro',
      description: 'Human capital strategist driving organizational success through people-first initiatives'
    },
    {
      title: 'UK L&D Leader',
      icon: Brain,
      path: '/leadership',
      description: 'Developing future-ready leaders for tomorrow\'s challenges'
    },
    {
      title: 'UK Reward Leader',
      icon: Briefcase,
      path: '/reward',
      description: 'Creating equitable and competitive compensation strategies'
    },
    {
      title: 'UK Sales Leader',
      icon: UserCog,
      path: '/sales',
      description: 'Driving sustainable revenue growth in a dynamic economy'
    },
    {
      title: 'UK Talent Acquisition',
      icon: UserPlus,
      path: '/talent',
      description: 'Building diverse, skilled teams for organizational success'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary to-tertiary text-white p-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 animate-fade-in">
          <h1 className="text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white to-secondary">
            UK Leadership Personas
          </h1>
          <p className="text-lg text-gray-300">
            Explore detailed insights into key leadership roles shaping UK businesses
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {personas.map((persona, index) => {
            const IconComponent = persona.icon;
            return (
              <Link
                key={persona.path}
                to={persona.path}
                className="transform hover:scale-105 transition-all duration-300 h-full group"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="bg-tertiary/50 backdrop-blur-sm rounded-xl p-8 shadow-xl border border-secondary/20 hover:border-secondary h-full flex flex-col items-center group-hover:bg-tertiary/60 transition-all duration-300">
                  <div className="bg-gradient-to-br from-secondary to-primary w-20 h-20 rounded-2xl flex items-center justify-center mb-6 transform group-hover:rotate-6 transition-transform duration-300">
                    <IconComponent className="w-10 h-10 text-white" />
                  </div>
                  <h2 className="text-2xl font-semibold text-center mb-4">{persona.title}</h2>
                  <p className="text-gray-300 text-center flex-grow">{persona.description}</p>
                </div>
              </Link>
            );
          })}
        </div>

        <div className="mt-12 text-center text-sm text-gray-400">
          © {new Date().getFullYear()} Korn Ferry. All rights reserved.
        </div>
      </div>
    </div>
  );
}

export default Index;