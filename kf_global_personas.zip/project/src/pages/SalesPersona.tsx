import React from 'react';
import PersonaLayout from '../components/PersonaLayout';
import PersonaSection from '../components/PersonaSection';

function SalesPersona() {
  const contentIdeas = [
    {
      title: "Selling Value, Not Just Price",
      trigger: "Challenge: Maintaining growth in uncertain markets",
      description: "Equip teams to communicate value propositions that resonate with cost-conscious UK customers, focusing on long-term partnerships over transactional relationships."
    },
    {
      title: "The Ethical Sales Playbook",
      trigger: "Pain Point: Meeting heightened trust expectations",
      description: "Embed ethical selling practices aligned with growing UK consumer expectations for sustainability and corporate responsibility, building lasting customer relationships."
    },
    {
      title: "Leading the Agile Sales Force",
      trigger: "Motivation: Empowering remote team success",
      description: "Master the art of managing and motivating remote sales teams across UK regions, leveraging technology to foster collaboration and drive consistent results."
    }
  ];

  return (
    <PersonaLayout title="UK Sales Leader Persona" contentIdeas={contentIdeas}>
      <PersonaSection
        title="Goal Statement"
        items={[
          'Drive sustainable revenue growth by building a high-performing (often remote) sales team, leveraging data-driven strategies, and adapting to evolving market and regulatory demands to ensure exceptional customer value in a dynamic economy.'
        ]}
      />
      
      <PersonaSection
        title="Key Needs"
        items={[
          'Regional market intelligence across British economic hubs',
          'Understanding of sector deals and levelling up fund opportunities',
          'Compliance with British consumer protection regulations',
          'Navigation of public sector procurement frameworks',
          'Adaptation to Financial Conduct Authority (FCA) requirements',
          'Strategic approach to Northern Powerhouse opportunities'
        ]}
      />
      
      <PersonaSection
        title="Frustrations & Pain Points"
        items={[
          'Complex public sector procurement processes post-Brexit',
          'Regional market access challenges beyond Southeast',
          'Adapting to British Standards Institution requirements',
          'Meeting sector-specific regulatory compliance',
          'Managing diverse regional business cultures'
        ]}
      />
      
      <PersonaSection
        title="What Makes This Persona Unique to the UK"
        items={[
          'Navigation of Crown Commercial Service frameworks',
          'Understanding of devolved administration procurement',
          'Compliance with British advertising standards',
          'Regional economic disparities and opportunities',
          'Sector-specific British regulatory requirements'
        ]}
      />
    </PersonaLayout>
  );
}

export default SalesPersona;