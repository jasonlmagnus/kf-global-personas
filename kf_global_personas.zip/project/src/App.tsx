import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Index from './pages/Index';
import CeoPersona from './pages/CeoPersona';
import ChroPersona from './pages/ChroPersona';
import LeadershipPersona from './pages/LeadershipPersona';
import RewardPersona from './pages/RewardPersona';
import SalesPersona from './pages/SalesPersona';
import TalentPersona from './pages/TalentPersona';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/ceo" element={<CeoPersona />} />
        <Route path="/chro" element={<ChroPersona />} />
        <Route path="/leadership" element={<LeadershipPersona />} />
        <Route path="/reward" element={<RewardPersona />} />
        <Route path="/sales" element={<SalesPersona />} />
        <Route path="/talent" element={<TalentPersona />} />
      </Routes>
    </Router>
  );
}

export default App;