import React from 'react';
import { Lightbulb } from 'lucide-react';

interface ContentIdea {
  title: string;
  trigger: string;
  description: string;
}

interface ContentIdeasProps {
  ideas: ContentIdea[];
}

function ContentIdeas({ ideas }: ContentIdeasProps) {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold text-secondary flex items-center gap-2">
        <Lightbulb className="w-6 h-6" />
        Content Ideas
      </h2>
      {ideas.map((idea, index) => (
        <div 
          key={index}
          className="bg-tertiary/30 backdrop-blur-sm rounded-lg p-6 border border-secondary/20 hover:border-secondary/40 transition-colors duration-300 animate-fade-in"
          style={{ animationDelay: `${index * 100}ms` }}
        >
          <h3 className="text-lg font-semibold text-white mb-2">{idea.title}</h3>
          <p className="text-secondary text-sm mb-3">{idea.trigger}</p>
          <p className="text-gray-300 text-sm">{idea.description}</p>
        </div>
      ))}
    </div>
  );
}

export default ContentIdeas;