import React from 'react';
import PersonaLayout from '../components/PersonaLayout';
import PersonaSection from '../components/PersonaSection';

function RewardPersona() {
  const contentIdeas = [
    {
      title: "The Equity Equation",
      trigger: "Challenge: Maintaining fairness amid cost pressures",
      description: "Design reward strategies that promote pay equity and transparency in the UK context, addressing cost-of-living pressures while meeting legal requirements."
    },
    {
      title: "Beyond the Salary",
      trigger: "Pain Point: Attracting talent in high inflation",
      description: "Leverage non-financial aspects of reward (well-being benefits, flexible work) to attract and retain UK talent without solely relying on salary increases in a high-inflation environment."
    },
    {
      title: "Navigating the ESG Maze",
      trigger: "Motivation: Authentic integration of sustainability",
      description: "Incorporate ESG metrics into UK executive and broader reward strategies, creating meaningful alignment with organizational values and stakeholder expectations."
    }
  ];

  return (
    <PersonaLayout title="UK Reward Leader Persona" contentIdeas={contentIdeas}>
      <PersonaSection
        title="Goal Statement"
        items={[
          'Design and implement equitable, competitive, and cost-effective reward strategies that attract and retain top talent, align with evolving regulations, and reflect organizational social and environmental values—ultimately supporting business success in a dynamic economic climate.'
        ]}
      />
      
      <PersonaSection
        title="Key Needs"
        items={[
          'Deep understanding of UK market compensation benchmarks and trends',
          'Strategies to address cost-of-living and inflation pressures through pay adjustments',
          'Expertise on UK pay transparency legislation and compliance requirements',
          'Solutions for designing hybrid and flexible work reward packages',
          'Frameworks for integrating ESG considerations into executive compensation',
          'Tools for conducting equal pay audits and addressing pay gaps',
          'Effective communication strategies for reward decisions',
          'Insights into employee financial well-being programs'
        ]}
      />
      
      <PersonaSection
        title="What Makes This Persona Unique to the UK"
        items={[
          'Cost-of-living and inflation pressures increase focus on pay adjustments and financial well-being',
          'Evolving UK regulatory landscape around pay transparency and minimum wage creates complex compliance needs',
          'Growing ESG considerations influence executive pay and broader reward strategies',
          'Hybrid and flexible work norms necessitate equitable reward solutions',
          'Heightened interest in fair pay and transparency drives internal audits and communication'
        ]}
      />
    </PersonaLayout>
  );
}

export default RewardPersona;