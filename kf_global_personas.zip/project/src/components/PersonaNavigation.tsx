import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface Route {
  path: string;
  title: string;
}

const routes: Route[] = [
  { path: '/ceo', title: 'UK CEO' },
  { path: '/chro', title: 'UK CHRO' },
  { path: '/leadership', title: 'UK L&D Leader' },
  { path: '/reward', title: 'UK Reward Leader' },
  { path: '/sales', title: 'UK Sales Leader' },
  { path: '/talent', title: 'UK Talent Acquisition' },
];

function PersonaNavigation() {
  const location = useLocation();
  const currentIndex = routes.findIndex(route => route.path === location.pathname);
  
  const prevRoute = currentIndex > 0 ? routes[currentIndex - 1] : routes[routes.length - 1];
  const nextRoute = currentIndex < routes.length - 1 ? routes[currentIndex + 1] : routes[0];

  return (
    <div className="flex items-center gap-4">
      <Link
        to={prevRoute.path}
        className="flex items-center text-gray-300 hover:text-secondary transition-colors group"
      >
        <ChevronLeft className="w-5 h-5 mr-1 group-hover:-translate-x-1 transition-transform" />
        <span className="hidden sm:inline">{prevRoute.title}</span>
      </Link>
      <Link
        to={nextRoute.path}
        className="flex items-center text-gray-300 hover:text-secondary transition-colors group"
      >
        <span className="hidden sm:inline">{nextRoute.title}</span>
        <ChevronRight className="w-5 h-5 ml-1 group-hover:translate-x-1 transition-transform" />
      </Link>
    </div>
  );
}

export default PersonaNavigation;