import React from 'react';
import PersonaLayout from '../components/PersonaLayout';
import PersonaSection from '../components/PersonaSection';

function ChroPersona() {
  const contentIdeas = [
    {
      title: "Beyond Headcount",
      trigger: "Challenge: Establishing HR as strategic business partner",
      description: "Demonstrate tangible ROI of HR programs in the context of UK economic pressures and post-Brexit challenges, using data to elevate HR's strategic position."
    },
    {
      title: "The Resilient Workforce Architect",
      trigger: "Pain Point: Building adaptability in uncertain times",
      description: "Design UK people strategies that create long-term agility and competitive advantage, preparing for ongoing economic, technological, and regulatory shifts."
    },
    {
      title: "Navigating the Ethical Tightrope",
      trigger: "Motivation: Leading responsible AI adoption",
      description: "Implement AI and HR technology aligned with UK GDPR standards and ethical principles, building employee trust while positioning HR as a strategic leader."
    }
  ];

  return (
    <PersonaLayout title="UK CHRO Persona" contentIdeas={contentIdeas}>
      <PersonaSection
        title="Goal Statement"
        items={[
          'Create a resilient, future-ready workforce by aligning people strategies with business objectives, championing diversity and well-being, and navigating evolving employment regulations to drive lasting organizational impact.'
        ]}
      />
      
      <PersonaSection
        title="Key Needs"
        items={[
          'Navigate IR35 reforms and contractor management in British tech sector',
          'Implement Working Time Regulations changes and flexible working rights',
          'Leverage Apprenticeship Levy and T-Level programs effectively',
          'Address regional salary disparities while maintaining competitiveness',
          'Comply with ethnicity pay gap reporting and gender pay gap requirements',
          'Manage implications of British pension auto-enrolment changes',
          'Navigate TUPE regulations in merger and acquisition scenarios',
          'Implement Mental Health First Aid standards across operations'
        ]}
      />
      
      <PersonaSection
        title="Key Responsibilities"
        items={[
          'Developing strategies aligned with British Skills and Post-16 Education Act',
          'Managing implications of Employment Bill reforms',
          'Leading EDI initiatives aligned with FCA diversity requirements',
          'Implementing statutory sick pay and family-friendly policies',
          'Ensuring compliance with settled status requirements',
          'Developing regional talent strategies across British tech hubs'
        ]}
      />
      
      <PersonaSection
        title="What Makes This Persona Unique to the UK"
        items={[
          'Managing statutory consultation requirements with British works councils',
          'Navigating regional variations in employment law across home nations',
          'Implementing British-specific holiday pay calculations and entitlements',
          'Addressing skills shortages in post-Brexit labor market',
          'Managing pension scheme obligations and lifetime allowance changes'
        ]}
      />
    </PersonaLayout>
  );
}

export default ChroPersona;