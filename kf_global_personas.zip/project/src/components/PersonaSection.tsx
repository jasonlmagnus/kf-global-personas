import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface PersonaSectionProps {
  title: string;
  items: string[];
}

function PersonaSection({ title, items }: PersonaSectionProps) {
  const [isExpanded, setIsExpanded] = useState(true);

  return (
    <div className="mb-8 bg-tertiary/50 backdrop-blur-sm rounded-xl p-6 border border-secondary/20 hover:border-secondary/40 transition-colors duration-300">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between text-2xl font-semibold mb-4 text-secondary hover:text-secondary/80 transition-colors"
      >
        <span>{title}</span>
        {isExpanded ? (
          <ChevronUp className="w-6 h-6" />
        ) : (
          <ChevronDown className="w-6 h-6" />
        )}
      </button>
      
      {isExpanded && (
        <ul className="space-y-3">
          {items.map((item, index) => (
            <li 
              key={index} 
              className="text-gray-300 flex items-start animate-fade-in"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <span className="text-secondary mr-3">•</span>
              <span>{item}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default PersonaSection;