import React from 'react';
import PersonaLayout from '../components/PersonaLayout';
import PersonaSection from '../components/PersonaSection';

function LeadershipPersona() {
  const contentIdeas = [
    {
      title: "The Learning Ecosystem",
      trigger: "Challenge: Creating lasting impact beyond training delivery",
      description: "Create holistic learning approaches that extend beyond formal training, focusing on post-program reinforcement and continuous development relevant to UK business challenges."
    },
    {
      title: "Measuring What Matters",
      trigger: "Pain Point: Demonstrating strategic value and ROI",
      description: "Identify and track key performance indicators that demonstrate direct impact of L&D initiatives on UK business outcomes, from hybrid team performance to regulatory adaptation."
    },
    {
      title: "From Content Curator to Capability Builder",
      trigger: "Motivation: Elevating L&D's strategic influence",
      description: "Evolve from traditional training delivery to strategic capability building, proactively addressing future skill needs driven by UK-specific trends in AI adoption and green economy."
    }
  ];

  return (
    <PersonaLayout title="UK L&D Leader Persona" contentIdeas={contentIdeas}>
      <PersonaSection
        title="Goal Statement"
        items={[
          'Create a continuous learning culture that shapes future-ready leaders, embraces technological change (AI), and fosters an inclusive, people-centric environment where employees thrive.'
        ]}
      />
      
      <PersonaSection
        title="Key Needs"
        items={[
          'Access to cutting-edge assessments and AI-driven platforms (LMS, analytics) to build leaders equipped for hybrid teams and emerging technologies.',
          'Programs and frameworks that emphasize resilience, change management, and empathy in an evolving UK business landscape.',
          'Customized and experiential learning methods (action learning, simulations, blended learning) that resonate with diverse UK audiences.',
          'Tailored solutions that tackle cultural nuances and immediate UK business challenges, rather than generic, off-the-shelf training.',
          'Robust metrics (engagement scores, retention data, post-program performance) to justify budget allocations and demonstrate the tangible benefit of L&D initiatives.',
          'Data-driven insights to refine programs and align them with evolving strategic goals.',
          'Post-program support (coaching, mentoring, and continuous reinforcement) to sustain leadership behaviors beyond the classroom.',
          'Knowledge-sharing communities for leaders to collaboratively solve on-the-job challenges.'
        ]}
      />
      
      <PersonaSection
        title="What Makes This Persona Unique to the UK"
        items={[
          'The hybrid and remote reality demands leadership frameworks tailored for such teams.',
          'A strong emphasis on integrating AI for personalized learning and ROI measurement, balanced with ethical concerns.',
          'DEI is a core strategic driver influencing all aspects of leadership development.',
          'There is high accountability for ROI, requiring data-backed justification for L&D spend.',
          'A pronounced focus on mental health, well-being, and empathetic leadership reflects UK societal and legislative trends.',
          'Consideration of unique UK legislation like the "Right to Disconnect".'
        ]}
      />
    </PersonaLayout>
  );
}

export default LeadershipPersona;