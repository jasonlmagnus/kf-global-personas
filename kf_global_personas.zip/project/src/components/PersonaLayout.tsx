import React, { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import PersonaNavigation from './PersonaNavigation';
import ContentIdeas from './ContentIdeas';

interface PersonaLayoutProps {
  children: ReactNode;
  title: string;
  contentIdeas: {
    title: string;
    trigger: string;
    description: string;
  }[];
}

function PersonaLayout({ children, title, contentIdeas }: PersonaLayoutProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary to-tertiary text-white p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-12">
          <Link
            to="/"
            className="inline-flex items-center text-gray-300 hover:text-secondary transition-colors group"
          >
            <ArrowLeft className="w-5 h-5 mr-2 group-hover:-translate-x-1 transition-transform" />
            Back to Index
          </Link>
          <PersonaNavigation />
        </div>
        
        <h1 className="text-4xl font-bold mb-12 text-center bg-clip-text text-transparent bg-gradient-to-r from-white to-secondary">
          {title}
        </h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6 animate-fade-in">
            {children}
          </div>
          <div className="lg:col-span-1">
            <ContentIdeas ideas={contentIdeas} />
          </div>
        </div>

        <div className="mt-12 text-center text-sm text-gray-400">
          © {new Date().getFullYear()}
        </div>
      </div>
    </div>
  );
}

export default PersonaLayout;